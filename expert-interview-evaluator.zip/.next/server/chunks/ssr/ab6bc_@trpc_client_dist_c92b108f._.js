module.exports = {

"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/createChain.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createChain": (()=>createChain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
;
/** @internal */ function createChain(opts) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
        function execute(index = 0, op = opts.op) {
            const next = opts.links[index];
            if (!next) {
                throw new Error('No more links to execute - did you forget to add an ending link?');
            }
            const subscription = next({
                op,
                next (nextOp) {
                    const nextObserver = execute(index + 1, nextOp);
                    return nextObserver;
                }
            });
            return subscription;
        }
        const obs$ = execute();
        return obs$.subscribe(observer);
    });
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "TRPCClientError": (()=>TRPCClientError)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/utils.mjs [app-ssr] (ecmascript)");
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function isTRPCClientError(cause) {
    return cause instanceof TRPCClientError || /**
     * @deprecated
     * Delete in next major
     */ cause instanceof Error && cause.name === 'TRPCClientError';
}
function isTRPCErrorResponse(obj) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(obj) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(obj['error']) && typeof obj['error']['code'] === 'number' && typeof obj['error']['message'] === 'string';
}
function getMessageFromUnknownError(err, fallback) {
    if (typeof err === 'string') {
        return err;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(err) && typeof err['message'] === 'string') {
        return err['message'];
    }
    return fallback;
}
class TRPCClientError extends Error {
    static from(_cause, opts = {}) {
        const cause = _cause;
        if (isTRPCClientError(cause)) {
            if (opts.meta) {
                // Decorate with meta error data
                cause.meta = {
                    ...cause.meta,
                    ...opts.meta
                };
            }
            return cause;
        }
        if (isTRPCErrorResponse(cause)) {
            return new TRPCClientError(cause.error.message, {
                ...opts,
                result: cause
            });
        }
        return new TRPCClientError(getMessageFromUnknownError(cause, 'Unknown error'), {
            ...opts,
            cause: cause
        });
    }
    constructor(message, opts){
        const cause = opts?.cause;
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore https://github.com/tc39/proposal-error-cause
        super(message, {
            cause
        }), // @ts-ignore override doesn't work in all environments due to "This member cannot have an 'override' modifier because it is not declared in the base class 'Error'"
        _define_property(this, "cause", void 0), _define_property(this, "shape", void 0), _define_property(this, "data", void 0), /**
   * Additional meta data about the error
   * In the case of HTTP-errors, we'll have `response` and potentially `responseJSON` here
   */ _define_property(this, "meta", void 0);
        this.meta = opts?.meta;
        this.cause = cause;
        this.shape = opts?.result?.error;
        this.data = opts?.result?.error.data;
        this.name = 'TRPCClientError';
        Object.setPrototypeOf(this, TRPCClientError.prototype);
    }
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "TRPCUntypedClient": (()=>TRPCUntypedClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$operators$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/operators.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$createChain$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/createChain.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
;
;
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
class TRPCUntypedClient {
    $request(opts) {
        const chain$ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$createChain$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createChain"])({
            links: this.links,
            op: {
                ...opts,
                context: opts.context ?? {},
                id: ++this.requestId
            }
        });
        return chain$.pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$operators$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["share"])());
    }
    async requestAsPromise(opts) {
        try {
            const req$ = this.$request(opts);
            const envelope = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observableToPromise"])(req$);
            const data = envelope.result.data;
            return data;
        } catch (err) {
            throw __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(err);
        }
    }
    query(path, input, opts) {
        return this.requestAsPromise({
            type: 'query',
            path,
            input,
            context: opts?.context,
            signal: opts?.signal
        });
    }
    mutation(path, input, opts) {
        return this.requestAsPromise({
            type: 'mutation',
            path,
            input,
            context: opts?.context,
            signal: opts?.signal
        });
    }
    subscription(path, input, opts) {
        const observable$ = this.$request({
            type: 'subscription',
            path,
            input,
            context: opts.context,
            signal: opts.signal
        });
        return observable$.subscribe({
            next (envelope) {
                switch(envelope.result.type){
                    case 'state':
                        {
                            opts.onConnectionStateChange?.(envelope.result);
                            break;
                        }
                    case 'started':
                        {
                            opts.onStarted?.({
                                context: envelope.context
                            });
                            break;
                        }
                    case 'stopped':
                        {
                            opts.onStopped?.();
                            break;
                        }
                    case 'data':
                    case undefined:
                        {
                            opts.onData?.(envelope.result.data);
                            break;
                        }
                }
            },
            error (err) {
                opts.onError?.(err);
            },
            complete () {
                opts.onComplete?.();
            }
        });
    }
    constructor(opts){
        _define_property(this, "links", void 0);
        _define_property(this, "runtime", void 0);
        _define_property(this, "requestId", void 0);
        this.requestId = 0;
        this.runtime = {};
        // Initialize the links
        this.links = opts.links.map((link)=>link(this.runtime));
    }
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCUntypedClient.mjs [app-ssr] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createTRPCUntypedClient": (()=>createTRPCUntypedClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)");
;
function createTRPCUntypedClient(opts) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCUntypedClient"](opts);
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCUntypedClient.mjs [app-ssr] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$createTRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCUntypedClient.mjs [app-ssr] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCClient.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "clientCallTypeToProcedureType": (()=>clientCallTypeToProcedureType),
    "createTRPCClient": (()=>createTRPCClient),
    "createTRPCClientProxy": (()=>createTRPCClientProxy),
    "getUntypedClient": (()=>getUntypedClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$createProxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/createProxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)");
;
;
const untypedClientSymbol = Symbol.for('trpc_untypedClient');
const clientCallTypeMap = {
    query: 'query',
    mutate: 'mutation',
    subscribe: 'subscription'
};
/** @internal */ const clientCallTypeToProcedureType = (clientCallType)=>{
    return clientCallTypeMap[clientCallType];
};
/**
 * @internal
 */ function createTRPCClientProxy(client) {
    const proxy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$createProxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createRecursiveProxy"])(({ path, args })=>{
        const pathCopy = [
            ...path
        ];
        const procedureType = clientCallTypeToProcedureType(pathCopy.pop());
        const fullPath = pathCopy.join('.');
        return client[procedureType](fullPath, ...args);
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$createProxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createFlatProxy"])((key)=>{
        if (key === untypedClientSymbol) {
            return client;
        }
        return proxy[key];
    });
}
function createTRPCClient(opts) {
    const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCUntypedClient"](opts);
    const proxy = createTRPCClientProxy(client);
    return proxy;
}
/**
 * Get an untyped client from a proxy client
 * @internal
 */ function getUntypedClient(client) {
    return client[untypedClientSymbol];
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/getFetch.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getFetch": (()=>getFetch)
});
const isFunction = (fn)=>typeof fn === 'function';
function getFetch(customFetchImpl) {
    if (customFetchImpl) {
        return customFetchImpl;
    }
    if (typeof window !== 'undefined' && isFunction(window.fetch)) {
        return window.fetch;
    }
    if (typeof globalThis !== 'undefined' && isFunction(globalThis.fetch)) {
        return globalThis.fetch;
    }
    throw new Error('No fetch implementation found');
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/contentTypes.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "isFormData": (()=>isFormData),
    "isNonJsonSerializable": (()=>isNonJsonSerializable),
    "isOctetType": (()=>isOctetType)
});
function isOctetType(input) {
    return input instanceof Uint8Array || // File extends from Blob but is only available in nodejs from v20
    input instanceof Blob;
}
function isFormData(input) {
    return input instanceof FormData;
}
function isNonJsonSerializable(input) {
    return isOctetType(input) || isFormData(input);
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/dataLoader.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-non-null-assertion */ /**
 * A function that should never be called unless we messed something up.
 */ __turbopack_context__.s({
    "dataLoader": (()=>dataLoader)
});
const throwFatalError = ()=>{
    throw new Error('Something went wrong. Please submit an issue at https://github.com/trpc/trpc/issues/new');
};
/**
 * Dataloader that's very inspired by https://github.com/graphql/dataloader
 * Less configuration, no caching, and allows you to cancel requests
 * When cancelling a single fetch the whole batch will be cancelled only when _all_ items are cancelled
 */ function dataLoader(batchLoader) {
    let pendingItems = null;
    let dispatchTimer = null;
    const destroyTimerAndPendingItems = ()=>{
        clearTimeout(dispatchTimer);
        dispatchTimer = null;
        pendingItems = null;
    };
    /**
   * Iterate through the items and split them into groups based on the `batchLoader`'s validate function
   */ function groupItems(items) {
        const groupedItems = [
            []
        ];
        let index = 0;
        while(true){
            const item = items[index];
            if (!item) {
                break;
            }
            const lastGroup = groupedItems[groupedItems.length - 1];
            if (item.aborted) {
                // Item was aborted before it was dispatched
                item.reject?.(new Error('Aborted'));
                index++;
                continue;
            }
            const isValid = batchLoader.validate(lastGroup.concat(item).map((it)=>it.key));
            if (isValid) {
                lastGroup.push(item);
                index++;
                continue;
            }
            if (lastGroup.length === 0) {
                item.reject?.(new Error('Input is too big for a single dispatch'));
                index++;
                continue;
            }
            // Create new group, next iteration will try to add the item to that
            groupedItems.push([]);
        }
        return groupedItems;
    }
    function dispatch() {
        const groupedItems = groupItems(pendingItems);
        destroyTimerAndPendingItems();
        // Create batches for each group of items
        for (const items of groupedItems){
            if (!items.length) {
                continue;
            }
            const batch = {
                items
            };
            for (const item of items){
                item.batch = batch;
            }
            const promise = batchLoader.fetch(batch.items.map((_item)=>_item.key));
            promise.then(async (result)=>{
                await Promise.all(result.map(async (valueOrPromise, index)=>{
                    const item = batch.items[index];
                    try {
                        const value = await Promise.resolve(valueOrPromise);
                        item.resolve?.(value);
                    } catch (cause) {
                        item.reject?.(cause);
                    }
                    item.batch = null;
                    item.reject = null;
                    item.resolve = null;
                }));
                for (const item of batch.items){
                    item.reject?.(new Error('Missing result'));
                    item.batch = null;
                }
            }).catch((cause)=>{
                for (const item of batch.items){
                    item.reject?.(cause);
                    item.batch = null;
                }
            });
        }
    }
    function load(key) {
        const item = {
            aborted: false,
            key,
            batch: null,
            resolve: throwFatalError,
            reject: throwFatalError
        };
        const promise = new Promise((resolve, reject)=>{
            item.reject = reject;
            item.resolve = resolve;
            if (!pendingItems) {
                pendingItems = [];
            }
            pendingItems.push(item);
        });
        if (!dispatchTimer) {
            dispatchTimer = setTimeout(dispatch);
        }
        return promise;
    }
    return {
        load
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/signals.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * Like `Promise.all()` but for abort signals
 * - When all signals have been aborted, the merged signal will be aborted
 * - If one signal is `null`, no signal will be aborted
 */ __turbopack_context__.s({
    "allAbortSignals": (()=>allAbortSignals),
    "raceAbortSignals": (()=>raceAbortSignals)
});
function allAbortSignals(...signals) {
    const ac = new AbortController();
    const count = signals.length;
    let abortedCount = 0;
    const onAbort = ()=>{
        if (++abortedCount === count) {
            ac.abort();
        }
    };
    for (const signal of signals){
        if (signal?.aborted) {
            onAbort();
        } else {
            signal?.addEventListener('abort', onAbort, {
                once: true
            });
        }
    }
    return ac.signal;
}
/**
 * Like `Promise.race` but for abort signals
 *
 * Basically, a ponyfill for
 * [`AbortSignal.any`](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal/any_static).
 */ function raceAbortSignals(...signals) {
    const ac = new AbortController();
    for (const signal of signals){
        if (signal?.aborted) {
            ac.abort();
        } else {
            signal?.addEventListener('abort', ()=>ac.abort(), {
                once: true
            });
        }
    }
    return ac.signal;
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/transformer.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @internal
 */ /**
 * @internal
 */ __turbopack_context__.s({
    "getTransformer": (()=>getTransformer)
});
function getTransformer(transformer) {
    const _transformer = transformer;
    if (!_transformer) {
        return {
            input: {
                serialize: (data)=>data,
                deserialize: (data)=>data
            },
            output: {
                serialize: (data)=>data,
                deserialize: (data)=>data
            }
        };
    }
    if ('input' in _transformer) {
        return _transformer;
    }
    return {
        input: _transformer,
        output: _transformer
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/httpUtils.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchHTTPResponse": (()=>fetchHTTPResponse),
    "getBody": (()=>getBody),
    "getInput": (()=>getInput),
    "getUrl": (()=>getUrl),
    "httpRequest": (()=>httpRequest),
    "jsonHttpRequester": (()=>jsonHttpRequester),
    "resolveHTTPLinkOptions": (()=>resolveHTTPLinkOptions)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$getFetch$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/getFetch.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/transformer.mjs [app-ssr] (ecmascript)");
;
;
function resolveHTTPLinkOptions(opts) {
    return {
        url: opts.url.toString(),
        fetch: opts.fetch,
        transformer: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTransformer"])(opts.transformer),
        methodOverride: opts.methodOverride
    };
}
// https://github.com/trpc/trpc/pull/669
function arrayToDict(array) {
    const dict = {};
    for(let index = 0; index < array.length; index++){
        const element = array[index];
        dict[index] = element;
    }
    return dict;
}
const METHOD = {
    query: 'GET',
    mutation: 'POST',
    subscription: 'PATCH'
};
function getInput(opts) {
    return 'input' in opts ? opts.transformer.input.serialize(opts.input) : arrayToDict(opts.inputs.map((_input)=>opts.transformer.input.serialize(_input)));
}
const getUrl = (opts)=>{
    const parts = opts.url.split('?');
    const base = parts[0].replace(/\/$/, ''); // Remove any trailing slashes
    let url = base + '/' + opts.path;
    const queryParts = [];
    if (parts[1]) {
        queryParts.push(parts[1]);
    }
    if ('inputs' in opts) {
        queryParts.push('batch=1');
    }
    if (opts.type === 'query' || opts.type === 'subscription') {
        const input = getInput(opts);
        if (input !== undefined && opts.methodOverride !== 'POST') {
            queryParts.push(`input=${encodeURIComponent(JSON.stringify(input))}`);
        }
    }
    if (queryParts.length) {
        url += '?' + queryParts.join('&');
    }
    return url;
};
const getBody = (opts)=>{
    if (opts.type === 'query' && opts.methodOverride !== 'POST') {
        return undefined;
    }
    const input = getInput(opts);
    return input !== undefined ? JSON.stringify(input) : undefined;
};
const jsonHttpRequester = (opts)=>{
    return httpRequest({
        ...opts,
        contentTypeHeader: 'application/json',
        getUrl,
        getBody
    });
};
/**
 * Polyfill for DOMException with AbortError name
 */ class AbortError extends Error {
    constructor(){
        const name = 'AbortError';
        super(name);
        this.name = name;
        this.message = name;
    }
}
/**
 * Polyfill for `signal.throwIfAborted()`
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal/throwIfAborted
 */ const throwIfAborted = (signal)=>{
    if (!signal?.aborted) {
        return;
    }
    // If available, use the native implementation
    signal.throwIfAborted?.();
    // If we have `DOMException`, use it
    if (typeof DOMException !== 'undefined') {
        throw new DOMException('AbortError', 'AbortError');
    }
    // Otherwise, use our own implementation
    throw new AbortError();
};
async function fetchHTTPResponse(opts) {
    throwIfAborted(opts.signal);
    const url = opts.getUrl(opts);
    const body = opts.getBody(opts);
    const { type } = opts;
    const resolvedHeaders = await (async ()=>{
        const heads = await opts.headers();
        if (Symbol.iterator in heads) {
            return Object.fromEntries(heads);
        }
        return heads;
    })();
    const headers = {
        ...opts.contentTypeHeader ? {
            'content-type': opts.contentTypeHeader
        } : {},
        ...opts.trpcAcceptHeader ? {
            'trpc-accept': opts.trpcAcceptHeader
        } : undefined,
        ...resolvedHeaders
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$getFetch$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFetch"])(opts.fetch)(url, {
        method: opts.methodOverride ?? METHOD[type],
        signal: opts.signal,
        body,
        headers
    });
}
async function httpRequest(opts) {
    const meta = {};
    const res = await fetchHTTPResponse(opts);
    meta.response = res;
    const json = await res.json();
    meta.responseJSON = json;
    return {
        json: json,
        meta
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "httpBatchLink": (()=>httpBatchLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/dataLoader.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/signals.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/httpUtils.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
/**
 * @see https://trpc.io/docs/client/links/httpBatchLink
 */ function httpBatchLink(opts) {
    const resolvedOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resolveHTTPLinkOptions"])(opts);
    const maxURLLength = opts.maxURLLength ?? Infinity;
    const maxItems = opts.maxItems ?? Infinity;
    return ()=>{
        const batchLoader = (type)=>{
            return {
                validate (batchOps) {
                    if (maxURLLength === Infinity && maxItems === Infinity) {
                        // escape hatch for quick calcs
                        return true;
                    }
                    if (batchOps.length > maxItems) {
                        return false;
                    }
                    const path = batchOps.map((op)=>op.path).join(',');
                    const inputs = batchOps.map((op)=>op.input);
                    const url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"])({
                        ...resolvedOpts,
                        type,
                        path,
                        inputs,
                        signal: null
                    });
                    return url.length <= maxURLLength;
                },
                async fetch (batchOps) {
                    const path = batchOps.map((op)=>op.path).join(',');
                    const inputs = batchOps.map((op)=>op.input);
                    const signal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["allAbortSignals"])(...batchOps.map((op)=>op.signal));
                    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsonHttpRequester"])({
                        ...resolvedOpts,
                        path,
                        inputs,
                        type,
                        headers () {
                            if (!opts.headers) {
                                return {};
                            }
                            if (typeof opts.headers === 'function') {
                                return opts.headers({
                                    opList: batchOps
                                });
                            }
                            return opts.headers;
                        },
                        signal
                    });
                    const resJSON = Array.isArray(res.json) ? res.json : batchOps.map(()=>res.json);
                    const result = resJSON.map((item)=>({
                            meta: res.meta,
                            json: item
                        }));
                    return result;
                }
            };
        };
        const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataLoader"])(batchLoader('query'));
        const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataLoader"])(batchLoader('mutation'));
        const loaders = {
            query,
            mutation
        };
        return ({ op })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                /* istanbul ignore if -- @preserve */ if (op.type === 'subscription') {
                    throw new Error('Subscriptions are unsupported by `httpLink` - use `httpSubscriptionLink` or `wsLink`');
                }
                const loader = loaders[op.type];
                const promise = loader.load(op);
                let _res = undefined;
                promise.then((res)=>{
                    _res = res;
                    const transformed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transformResult"])(res.json, resolvedOpts.transformer.output);
                    if (!transformed.ok) {
                        observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(transformed.error, {
                            meta: res.meta
                        }));
                        return;
                    }
                    observer.next({
                        context: res.meta,
                        result: transformed.result
                    });
                    observer.complete();
                }).catch((err)=>{
                    observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(err, {
                        meta: _res?.meta
                    }));
                });
                return ()=>{
                // noop
                };
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchStreamLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "httpBatchStreamLink": (()=>httpBatchStreamLink),
    "unstable_httpBatchStreamLink": (()=>unstable_httpBatchStreamLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$stream$2f$jsonl$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/stream/jsonl.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/dataLoader.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/signals.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/httpUtils.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
/**
 * @see https://trpc.io/docs/client/links/httpBatchStreamLink
 */ function httpBatchStreamLink(opts) {
    const resolvedOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resolveHTTPLinkOptions"])(opts);
    const maxURLLength = opts.maxURLLength ?? Infinity;
    const maxItems = opts.maxItems ?? Infinity;
    return ()=>{
        const batchLoader = (type)=>{
            return {
                validate (batchOps) {
                    if (maxURLLength === Infinity && maxItems === Infinity) {
                        // escape hatch for quick calcs
                        return true;
                    }
                    if (batchOps.length > maxItems) {
                        return false;
                    }
                    const path = batchOps.map((op)=>op.path).join(',');
                    const inputs = batchOps.map((op)=>op.input);
                    const url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"])({
                        ...resolvedOpts,
                        type,
                        path,
                        inputs,
                        signal: null
                    });
                    return url.length <= maxURLLength;
                },
                async fetch (batchOps) {
                    const path = batchOps.map((op)=>op.path).join(',');
                    const inputs = batchOps.map((op)=>op.input);
                    const batchSignals = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["allAbortSignals"])(...batchOps.map((op)=>op.signal));
                    const abortController = new AbortController();
                    const responsePromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchHTTPResponse"])({
                        ...resolvedOpts,
                        signal: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["raceAbortSignals"])(batchSignals, abortController.signal),
                        type,
                        contentTypeHeader: 'application/json',
                        trpcAcceptHeader: 'application/jsonl',
                        getUrl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"],
                        getBody: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBody"],
                        inputs,
                        path,
                        headers () {
                            if (!opts.headers) {
                                return {};
                            }
                            if (typeof opts.headers === 'function') {
                                return opts.headers({
                                    opList: batchOps
                                });
                            }
                            return opts.headers;
                        }
                    });
                    const res = await responsePromise;
                    const [head] = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$stream$2f$jsonl$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsonlStreamConsumer"])({
                        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                        from: res.body,
                        deserialize: resolvedOpts.transformer.output.deserialize,
                        // onError: console.error,
                        formatError (opts) {
                            const error = opts.error;
                            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from({
                                error
                            });
                        },
                        abortController
                    });
                    const promises = Object.keys(batchOps).map(async (key)=>{
                        let json = await Promise.resolve(head[key]);
                        if ('result' in json) {
                            /**
                 * Not very pretty, but we need to unwrap nested data as promises
                 * Our stream producer will only resolve top-level async values or async values that are directly nested in another async value
                 */ const result = await Promise.resolve(json.result);
                            json = {
                                result: {
                                    data: await Promise.resolve(result.data)
                                }
                            };
                        }
                        return {
                            json,
                            meta: {
                                response: res
                            }
                        };
                    });
                    return promises;
                }
            };
        };
        const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataLoader"])(batchLoader('query'));
        const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$dataLoader$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataLoader"])(batchLoader('mutation'));
        const loaders = {
            query,
            mutation
        };
        return ({ op })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                /* istanbul ignore if -- @preserve */ if (op.type === 'subscription') {
                    throw new Error('Subscriptions are unsupported by `httpBatchStreamLink` - use `httpSubscriptionLink` or `wsLink`');
                }
                const loader = loaders[op.type];
                const promise = loader.load(op);
                let _res = undefined;
                promise.then((res)=>{
                    _res = res;
                    if ('error' in res.json) {
                        observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(res.json, {
                            meta: res.meta
                        }));
                        return;
                    } else if ('result' in res.json) {
                        observer.next({
                            context: res.meta,
                            result: res.json.result
                        });
                        observer.complete();
                        return;
                    }
                    observer.complete();
                }).catch((err)=>{
                    observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(err, {
                        meta: _res?.meta
                    }));
                });
                return ()=>{
                // noop
                };
            });
        };
    };
}
/**
 * @deprecated use {@link httpBatchStreamLink} instead
 */ const unstable_httpBatchStreamLink = httpBatchStreamLink;
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "httpLink": (()=>httpLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/httpUtils.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$contentTypes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/contentTypes.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
const universalRequester = (opts)=>{
    if ('input' in opts) {
        const { input } = opts;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$contentTypes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isFormData"])(input)) {
            if (opts.type !== 'mutation' && opts.methodOverride !== 'POST') {
                throw new Error('FormData is only supported for mutations');
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["httpRequest"])({
                ...opts,
                // The browser will set this automatically and include the boundary= in it
                contentTypeHeader: undefined,
                getUrl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"],
                getBody: ()=>input
            });
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$contentTypes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isOctetType"])(input)) {
            if (opts.type !== 'mutation' && opts.methodOverride !== 'POST') {
                throw new Error('Octet type input is only supported for mutations');
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["httpRequest"])({
                ...opts,
                contentTypeHeader: 'application/octet-stream',
                getUrl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"],
                getBody: ()=>input
            });
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsonHttpRequester"])(opts);
};
/**
 * @see https://trpc.io/docs/client/links/httpLink
 */ function httpLink(opts) {
    const resolvedOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resolveHTTPLinkOptions"])(opts);
    return ()=>{
        return ({ op })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                const { path, input, type } = op;
                /* istanbul ignore if -- @preserve */ if (type === 'subscription') {
                    throw new Error('Subscriptions are unsupported by `httpLink` - use `httpSubscriptionLink` or `wsLink`');
                }
                const request = universalRequester({
                    ...resolvedOpts,
                    type,
                    path,
                    input,
                    signal: op.signal,
                    headers () {
                        if (!opts.headers) {
                            return {};
                        }
                        if (typeof opts.headers === 'function') {
                            return opts.headers({
                                op
                            });
                        }
                        return opts.headers;
                    }
                });
                let meta = undefined;
                request.then((res)=>{
                    meta = res.meta;
                    const transformed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transformResult"])(res.json, resolvedOpts.transformer.output);
                    if (!transformed.ok) {
                        observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(transformed.error, {
                            meta
                        }));
                        return;
                    }
                    observer.next({
                        context: res.meta,
                        result: transformed.result
                    });
                    observer.complete();
                }).catch((cause)=>{
                    observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(cause, {
                        meta
                    }));
                });
                return ()=>{
                // noop
                };
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/loggerLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "loggerLink": (()=>loggerLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$operators$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/operators.mjs [app-ssr] (ecmascript)");
;
/// <reference lib="dom.iterable" />
// `dom.iterable` types are explicitly required for extracting `FormData` values,
// as all implementations of `Symbol.iterable` are separated from the main `dom` types.
// Using triple-slash directive makes sure that it will be available,
// even if end-user `tsconfig.json` omits it in the `lib` array.
function isFormData(value) {
    if (typeof FormData === 'undefined') {
        // FormData is not supported
        return false;
    }
    return value instanceof FormData;
}
const palettes = {
    css: {
        query: [
            '72e3ff',
            '3fb0d8'
        ],
        mutation: [
            'c5a3fc',
            '904dfc'
        ],
        subscription: [
            'ff49e1',
            'd83fbe'
        ]
    },
    ansi: {
        regular: {
            // Cyan background, black and white text respectively
            query: [
                '\x1b[30;46m',
                '\x1b[97;46m'
            ],
            // Magenta background, black and white text respectively
            mutation: [
                '\x1b[30;45m',
                '\x1b[97;45m'
            ],
            // Green background, black and white text respectively
            subscription: [
                '\x1b[30;42m',
                '\x1b[97;42m'
            ]
        },
        bold: {
            query: [
                '\x1b[1;30;46m',
                '\x1b[1;97;46m'
            ],
            mutation: [
                '\x1b[1;30;45m',
                '\x1b[1;97;45m'
            ],
            subscription: [
                '\x1b[1;30;42m',
                '\x1b[1;97;42m'
            ]
        }
    }
};
function constructPartsAndArgs(opts) {
    const { direction, type, withContext, path, id, input } = opts;
    const parts = [];
    const args = [];
    if (opts.colorMode === 'none') {
        parts.push(direction === 'up' ? '>>' : '<<', type, `#${id}`, path);
    } else if (opts.colorMode === 'ansi') {
        const [lightRegular, darkRegular] = palettes.ansi.regular[type];
        const [lightBold, darkBold] = palettes.ansi.bold[type];
        const reset = '\x1b[0m';
        parts.push(direction === 'up' ? lightRegular : darkRegular, direction === 'up' ? '>>' : '<<', type, direction === 'up' ? lightBold : darkBold, `#${id}`, path, reset);
    } else {
        // css color mode
        const [light, dark] = palettes.css[type];
        const css = `
    background-color: #${direction === 'up' ? light : dark};
    color: ${direction === 'up' ? 'black' : 'white'};
    padding: 2px;
  `;
        parts.push('%c', direction === 'up' ? '>>' : '<<', type, `#${id}`, `%c${path}%c`, '%O');
        args.push(css, `${css}; font-weight: bold;`, `${css}; font-weight: normal;`);
    }
    if (direction === 'up') {
        args.push(withContext ? {
            input,
            context: opts.context
        } : {
            input
        });
    } else {
        args.push({
            input,
            result: opts.result,
            elapsedMs: opts.elapsedMs,
            ...withContext && {
                context: opts.context
            }
        });
    }
    return {
        parts,
        args
    };
}
// maybe this should be moved to it's own package
const defaultLogger = ({ c = console, colorMode = 'css', withContext })=>(props)=>{
        const rawInput = props.input;
        const input = isFormData(rawInput) ? Object.fromEntries(rawInput) : rawInput;
        const { parts, args } = constructPartsAndArgs({
            ...props,
            colorMode,
            input,
            withContext
        });
        const fn = props.direction === 'down' && props.result && (props.result instanceof Error || 'error' in props.result.result && props.result.result.error) ? 'error' : 'log';
        c[fn].apply(null, [
            parts.join(' ')
        ].concat(args));
    };
/**
 * @see https://trpc.io/docs/v11/client/links/loggerLink
 */ function loggerLink(opts = {}) {
    const { enabled = ()=>true } = opts;
    const colorMode = opts.colorMode ?? (typeof window === 'undefined' ? 'ansi' : 'css');
    const withContext = opts.withContext ?? colorMode === 'css';
    const { logger = defaultLogger({
        c: opts.console,
        colorMode,
        withContext
    }) } = opts;
    return ()=>{
        return ({ op, next })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                // ->
                if (enabled({
                    ...op,
                    direction: 'up'
                })) {
                    logger({
                        ...op,
                        direction: 'up'
                    });
                }
                const requestStartTime = Date.now();
                function logResult(result) {
                    const elapsedMs = Date.now() - requestStartTime;
                    if (enabled({
                        ...op,
                        direction: 'down',
                        result
                    })) {
                        logger({
                            ...op,
                            direction: 'down',
                            elapsedMs,
                            result
                        });
                    }
                }
                return next(op).pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$operators$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tap"])({
                    next (result) {
                        logResult(result);
                    },
                    error (result) {
                        logResult(result);
                    }
                })).subscribe(observer);
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/splitLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "splitLink": (()=>splitLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$createChain$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/createChain.mjs [app-ssr] (ecmascript)");
;
;
function asArray(value) {
    return Array.isArray(value) ? value : [
        value
    ];
}
function splitLink(opts) {
    return (runtime)=>{
        const yes = asArray(opts.true).map((link)=>link(runtime));
        const no = asArray(opts.false).map((link)=>link(runtime));
        return (props)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                const links = opts.condition(props.op) ? yes : no;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$createChain$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createChain"])({
                    op: props.op,
                    links
                }).subscribe(observer);
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/options.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "exponentialBackoff": (()=>exponentialBackoff),
    "keepAliveDefaults": (()=>keepAliveDefaults),
    "lazyDefaults": (()=>lazyDefaults)
});
const lazyDefaults = {
    enabled: false,
    closeMs: 0
};
const keepAliveDefaults = {
    enabled: false,
    pongTimeoutMs: 1000,
    intervalMs: 5000
};
/**
 * Calculates a delay for exponential backoff based on the retry attempt index.
 * The delay starts at 0 for the first attempt and doubles for each subsequent attempt,
 * capped at 30 seconds.
 */ const exponentialBackoff = (attemptIndex)=>{
    return attemptIndex === 0 ? 0 : Math.min(1000 * 2 ** attemptIndex, 30000);
};
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/urlWithConnectionParams.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * Get the result of a value or function that returns a value
 * It also optionally accepts typesafe arguments for the function
 */ __turbopack_context__.s({
    "resultOf": (()=>resultOf)
});
const resultOf = (value, ...args)=>{
    return typeof value === 'function' ? value(...args) : value;
};
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/utils.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ResettableTimeout": (()=>ResettableTimeout),
    "TRPCWebSocketClosedError": (()=>TRPCWebSocketClosedError),
    "buildConnectionMessage": (()=>buildConnectionMessage),
    "prepareUrl": (()=>prepareUrl),
    "withResolvers": (()=>withResolvers)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/urlWithConnectionParams.mjs [app-ssr] (ecmascript)");
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
class TRPCWebSocketClosedError extends Error {
    constructor(opts){
        super(opts.message, {
            cause: opts.cause
        });
        this.name = 'TRPCWebSocketClosedError';
        Object.setPrototypeOf(this, TRPCWebSocketClosedError.prototype);
    }
}
/**
 * Utility class for managing a timeout that can be started, stopped, and reset.
 * Useful for scenarios where the timeout duration is reset dynamically based on events.
 */ class ResettableTimeout {
    /**
   * Resets the current timeout, restarting it with the same duration.
   * Does nothing if no timeout is active.
   */ reset() {
        if (!this.timeout) return;
        clearTimeout(this.timeout);
        this.timeout = setTimeout(this.onTimeout, this.timeoutMs);
    }
    start() {
        clearTimeout(this.timeout);
        this.timeout = setTimeout(this.onTimeout, this.timeoutMs);
    }
    stop() {
        clearTimeout(this.timeout);
        this.timeout = undefined;
    }
    constructor(onTimeout, timeoutMs){
        _define_property(this, "onTimeout", void 0);
        _define_property(this, "timeoutMs", void 0);
        _define_property(this, "timeout", void 0);
        this.onTimeout = onTimeout;
        this.timeoutMs = timeoutMs;
    }
}
// Ponyfill for Promise.withResolvers https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/withResolvers
function withResolvers() {
    let resolve;
    let reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    return {
        promise,
        resolve: resolve,
        reject: reject
    };
}
/**
 * Resolves a WebSocket URL and optionally appends connection parameters.
 *
 * If connectionParams are provided, appends 'connectionParams=1' query parameter.
 */ async function prepareUrl(urlOptions) {
    const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resultOf"])(urlOptions.url);
    if (!urlOptions.connectionParams) return url;
    // append `?connectionParams=1` when connection params are used
    const prefix = url.includes('?') ? '&' : '?';
    const connectionParams = `${prefix}connectionParams=1`;
    return url + connectionParams;
}
async function buildConnectionMessage(connectionParams) {
    const message = {
        method: 'connectionParams',
        data: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resultOf"])(connectionParams)
    };
    return JSON.stringify(message);
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/requestManager.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "RequestManager": (()=>RequestManager)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/utils.mjs [app-ssr] (ecmascript)");
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * Manages WebSocket requests, tracking their lifecycle and providing utility methods
 * for handling outgoing and pending requests.
 *
 * - **Outgoing requests**: Requests that are queued and waiting to be sent.
 * - **Pending requests**: Requests that have been sent and are in flight awaiting a response.
 *   For subscriptions, multiple responses may be received until the subscription is closed.
 */ class RequestManager {
    /**
   * Registers a new request by adding it to the outgoing queue and setting up
   * callbacks for lifecycle events such as completion or error.
   *
   * @param message - The outgoing message to be sent.
   * @param callbacks - Callback functions to observe the request's state.
   * @returns A cleanup function to manually remove the request.
   */ register(message, callbacks) {
        const { promise: end, resolve } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["withResolvers"])();
        this.outgoingRequests.push({
            id: String(message.id),
            message,
            end,
            callbacks: {
                next: callbacks.next,
                complete: ()=>{
                    callbacks.complete();
                    resolve();
                },
                error: (e)=>{
                    callbacks.error(e);
                    resolve();
                }
            }
        });
        return ()=>{
            this.delete(message.id);
            callbacks.complete();
            resolve();
        };
    }
    /**
   * Deletes a request from both the outgoing and pending collections, if it exists.
   */ delete(messageId) {
        if (messageId === null) return;
        this.outgoingRequests = this.outgoingRequests.filter(({ id })=>id !== String(messageId));
        delete this.pendingRequests[String(messageId)];
    }
    /**
   * Moves all outgoing requests to the pending state and clears the outgoing queue.
   *
   * The caller is expected to handle the actual sending of the requests
   * (e.g., sending them over the network) after this method is called.
   *
   * @returns The list of requests that were transitioned to the pending state.
   */ flush() {
        const requests = this.outgoingRequests;
        this.outgoingRequests = [];
        for (const request of requests){
            this.pendingRequests[request.id] = request;
        }
        return requests;
    }
    /**
   * Retrieves all currently pending requests, which are in flight awaiting responses
   * or handling ongoing subscriptions.
   */ getPendingRequests() {
        return Object.values(this.pendingRequests);
    }
    /**
   * Retrieves a specific pending request by its message ID.
   */ getPendingRequest(messageId) {
        if (messageId === null) return null;
        return this.pendingRequests[String(messageId)];
    }
    /**
   * Retrieves all outgoing requests, which are waiting to be sent.
   */ getOutgoingRequests() {
        return this.outgoingRequests;
    }
    /**
   * Retrieves all requests, both outgoing and pending, with their respective states.
   *
   * @returns An array of all requests with their state ("outgoing" or "pending").
   */ getRequests() {
        return [
            ...this.getOutgoingRequests().map((request)=>({
                    state: 'outgoing',
                    message: request.message,
                    end: request.end,
                    callbacks: request.callbacks
                })),
            ...this.getPendingRequests().map((request)=>({
                    state: 'pending',
                    message: request.message,
                    end: request.end,
                    callbacks: request.callbacks
                }))
        ];
    }
    /**
   * Checks if there are any pending requests, including ongoing subscriptions.
   */ hasPendingRequests() {
        return this.getPendingRequests().length > 0;
    }
    /**
   * Checks if there are any outgoing requests waiting to be sent.
   */ hasOutgoingRequests() {
        return this.outgoingRequests.length > 0;
    }
    constructor(){
        /**
   * Stores requests that are outgoing, meaning they are registered but not yet sent over the WebSocket.
   */ _define_property(this, "outgoingRequests", new Array());
        /**
   * Stores requests that are pending (in flight), meaning they have been sent over the WebSocket
   * and are awaiting responses. For subscriptions, this includes requests
   * that may receive multiple responses.
   */ _define_property(this, "pendingRequests", {});
    }
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/wsConnection.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "WsConnection": (()=>WsConnection),
    "backwardCompatibility": (()=>backwardCompatibility)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/behaviorSubject.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/utils.mjs [app-ssr] (ecmascript)");
;
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * Opens a WebSocket connection asynchronously and returns a promise
 * that resolves when the connection is successfully established.
 * The promise rejects if an error occurs during the connection attempt.
 */ function asyncWsOpen(ws) {
    const { promise, resolve, reject } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["withResolvers"])();
    ws.addEventListener('open', ()=>{
        ws.removeEventListener('error', reject);
        resolve();
    });
    ws.addEventListener('error', reject);
    return promise;
}
/**
 * Sets up a periodic ping-pong mechanism to keep the WebSocket connection alive.
 *
 * - Sends "PING" messages at regular intervals defined by `intervalMs`.
 * - If a "PONG" response is not received within the `pongTimeoutMs`, the WebSocket is closed.
 * - The ping timer resets upon receiving any message to maintain activity.
 * - Automatically starts the ping process when the WebSocket connection is opened.
 * - Cleans up timers when the WebSocket is closed.
 *
 * @param ws - The WebSocket instance to manage.
 * @param options - Configuration options for ping-pong intervals and timeouts.
 */ function setupPingInterval(ws, { intervalMs, pongTimeoutMs }) {
    let pingTimeout;
    let pongTimeout;
    function start() {
        pingTimeout = setTimeout(()=>{
            ws.send('PING');
            pongTimeout = setTimeout(()=>{
                ws.close();
            }, pongTimeoutMs);
        }, intervalMs);
    }
    function reset() {
        clearTimeout(pingTimeout);
        start();
    }
    function pong() {
        clearTimeout(pongTimeout);
        reset();
    }
    ws.addEventListener('open', start);
    ws.addEventListener('message', ({ data })=>{
        clearTimeout(pingTimeout);
        start();
        if (data === 'PONG') {
            pong();
        }
    });
    ws.addEventListener('close', ()=>{
        clearTimeout(pingTimeout);
        clearTimeout(pongTimeout);
    });
}
/**
 * Manages a WebSocket connection with support for reconnection, keep-alive mechanisms,
 * and observable state tracking.
 */ class WsConnection {
    get ws() {
        return this.wsObservable.get();
    }
    set ws(ws) {
        this.wsObservable.next(ws);
    }
    /**
   * Checks if the WebSocket connection is open and ready to communicate.
   */ isOpen() {
        return !!this.ws && this.ws.readyState === this.WebSocketPonyfill.OPEN && !this.openPromise;
    }
    /**
   * Checks if the WebSocket connection is closed or in the process of closing.
   */ isClosed() {
        return !!this.ws && (this.ws.readyState === this.WebSocketPonyfill.CLOSING || this.ws.readyState === this.WebSocketPonyfill.CLOSED);
    }
    async open() {
        if (this.openPromise) return this.openPromise;
        this.id = ++WsConnection.connectCount;
        const wsPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["prepareUrl"])(this.urlOptions).then((url)=>new this.WebSocketPonyfill(url));
        this.openPromise = wsPromise.then(async (ws)=>{
            this.ws = ws;
            // Setup ping listener
            ws.addEventListener('message', function({ data }) {
                if (data === 'PING') {
                    this.send('PONG');
                }
            });
            if (this.keepAliveOpts.enabled) {
                setupPingInterval(ws, this.keepAliveOpts);
            }
            ws.addEventListener('close', ()=>{
                if (this.ws === ws) {
                    this.ws = null;
                }
            });
            await asyncWsOpen(ws);
            if (this.urlOptions.connectionParams) {
                ws.send(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buildConnectionMessage"])(this.urlOptions.connectionParams));
            }
        });
        try {
            await this.openPromise;
        } finally{
            this.openPromise = null;
        }
    }
    /**
   * Closes the WebSocket connection gracefully.
   * Waits for any ongoing open operation to complete before closing.
   */ async close() {
        try {
            await this.openPromise;
        } finally{
            this.ws?.close();
        }
    }
    constructor(opts){
        _define_property(this, "id", ++WsConnection.connectCount);
        _define_property(this, "WebSocketPonyfill", void 0);
        _define_property(this, "urlOptions", void 0);
        _define_property(this, "keepAliveOpts", void 0);
        _define_property(this, "wsObservable", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["behaviorSubject"])(null));
        /**
   * Manages the WebSocket opening process, ensuring that only one open operation
   * occurs at a time. Tracks the ongoing operation with `openPromise` to avoid
   * redundant calls and ensure proper synchronization.
   *
   * Sets up the keep-alive mechanism and necessary event listeners for the connection.
   *
   * @returns A promise that resolves once the WebSocket connection is successfully opened.
   */ _define_property(this, "openPromise", null);
        this.WebSocketPonyfill = opts.WebSocketPonyfill ?? WebSocket;
        if (!this.WebSocketPonyfill) {
            throw new Error("No WebSocket implementation found - you probably don't want to use this on the server, but if you do you need to pass a `WebSocket`-ponyfill");
        }
        this.urlOptions = opts.urlOptions;
        this.keepAliveOpts = opts.keepAlive;
    }
}
_define_property(WsConnection, "connectCount", 0);
/**
 * Provides a backward-compatible representation of the connection state.
 */ function backwardCompatibility(connection) {
    if (connection.isOpen()) {
        return {
            id: connection.id,
            state: 'open',
            ws: connection.ws
        };
    }
    if (connection.isClosed()) {
        return {
            id: connection.id,
            state: 'closed',
            ws: connection.ws
        };
    }
    if (!connection.ws) {
        return null;
    }
    return {
        id: connection.id,
        state: 'connecting',
        ws: connection.ws
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/wsClient.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "WsClient": (()=>WsClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/behaviorSubject.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/utils.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$options$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/options.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$requestManager$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/requestManager.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/utils.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$wsConnection$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/wsConnection.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * A WebSocket client for managing TRPC operations, supporting lazy initialization,
 * reconnection, keep-alive, and request management.
 */ class WsClient {
    /**
   * Opens the WebSocket connection. Handles reconnection attempts and updates
   * the connection state accordingly.
   */ async open() {
        this.allowReconnect = true;
        if (this.connectionState.get().state !== 'connecting') {
            this.connectionState.next({
                type: 'state',
                state: 'connecting',
                error: null
            });
        }
        try {
            await this.activeConnection.open();
        } catch (error) {
            this.reconnect(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                message: 'Initialization error',
                cause: error
            }));
            return this.reconnecting;
        }
    }
    /**
   * Closes the WebSocket connection and stops managing requests.
   * Ensures all outgoing and pending requests are properly finalized.
   */ async close() {
        this.allowReconnect = false;
        this.inactivityTimeout.stop();
        const requestsToAwait = [];
        for (const request of this.requestManager.getRequests()){
            if (request.message.method === 'subscription') {
                request.callbacks.complete();
            } else if (request.state === 'outgoing') {
                request.callbacks.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                    message: 'Closed before connection was established'
                })));
            } else {
                requestsToAwait.push(request.end);
            }
        }
        await Promise.all(requestsToAwait).catch(()=>null);
        await this.activeConnection.close().catch(()=>null);
        this.connectionState.next({
            type: 'state',
            state: 'idle',
            error: null
        });
    }
    /**
   * Method to request the server.
   * Handles data transformation, batching of requests, and subscription lifecycle.
   *
   * @param op - The operation details including id, type, path, input and signal
   * @param transformer - Data transformer for serializing requests and deserializing responses
   * @param lastEventId - Optional ID of the last received event for subscriptions
   *
   * @returns An observable that emits operation results and handles cleanup
   */ request({ op: { id, type, path, input, signal }, transformer, lastEventId }) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
            const abort = this.batchSend({
                id,
                method: type,
                params: {
                    input: transformer.input.serialize(input),
                    path,
                    lastEventId
                }
            }, {
                ...observer,
                next (event) {
                    const transformed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transformResult"])(event, transformer.output);
                    if (!transformed.ok) {
                        observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(transformed.error));
                        return;
                    }
                    observer.next({
                        result: transformed.result
                    });
                }
            });
            return ()=>{
                abort();
                if (type === 'subscription' && this.activeConnection.isOpen()) {
                    this.send({
                        id,
                        method: 'subscription.stop'
                    });
                }
                signal?.removeEventListener('abort', abort);
            };
        });
    }
    get connection() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$wsConnection$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["backwardCompatibility"])(this.activeConnection);
    }
    reconnect(closedError) {
        this.connectionState.next({
            type: 'state',
            state: 'connecting',
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(closedError)
        });
        if (this.reconnecting) return;
        const tryReconnect = async (attemptIndex)=>{
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sleep"])(this.reconnectRetryDelay(attemptIndex));
                if (this.allowReconnect) {
                    await this.activeConnection.close();
                    await this.activeConnection.open();
                    if (this.requestManager.hasPendingRequests()) {
                        this.send(this.requestManager.getPendingRequests().map(({ message })=>message));
                    }
                }
                this.reconnecting = null;
            } catch  {
                await tryReconnect(attemptIndex + 1);
            }
        };
        this.reconnecting = tryReconnect(0);
    }
    setupWebSocketListeners(ws) {
        const handleCloseOrError = (cause)=>{
            const reqs = this.requestManager.getPendingRequests();
            for (const { message, callbacks } of reqs){
                if (message.method === 'subscription') continue;
                callbacks.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(cause ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                    message: 'WebSocket closed',
                    cause
                })));
                this.requestManager.delete(message.id);
            }
        };
        ws.addEventListener('open', ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["run"])(async ()=>{
                if (this.lazyMode) {
                    this.inactivityTimeout.start();
                }
                this.callbacks.onOpen?.();
                this.connectionState.next({
                    type: 'state',
                    state: 'pending',
                    error: null
                });
            }).catch((error)=>{
                ws.close(3000);
                handleCloseOrError(error);
            });
        });
        ws.addEventListener('message', ({ data })=>{
            this.inactivityTimeout.reset();
            if (typeof data !== 'string' || [
                'PING',
                'PONG'
            ].includes(data)) return;
            const incomingMessage = JSON.parse(data);
            if ('method' in incomingMessage) {
                this.handleIncomingRequest(incomingMessage);
                return;
            }
            this.handleResponseMessage(incomingMessage);
        });
        ws.addEventListener('close', (event)=>{
            handleCloseOrError(event);
            this.callbacks.onClose?.(event);
            if (!this.lazyMode) {
                this.reconnect(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                    message: 'WebSocket closed',
                    cause: event
                }));
            }
        });
        ws.addEventListener('error', (event)=>{
            handleCloseOrError(event);
            this.callbacks.onError?.(event);
            this.reconnect(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                message: 'WebSocket closed',
                cause: event
            }));
        });
    }
    handleResponseMessage(message) {
        const request = this.requestManager.getPendingRequest(message.id);
        if (!request) return;
        request.callbacks.next(message);
        let completed = true;
        if ('result' in message && request.message.method === 'subscription') {
            if (message.result.type === 'data') {
                request.message.params.lastEventId = message.result.id;
            }
            if (message.result.type !== 'stopped') {
                completed = false;
            }
        }
        if (completed) {
            request.callbacks.complete();
            this.requestManager.delete(message.id);
        }
    }
    handleIncomingRequest(message) {
        if (message.method === 'reconnect') {
            this.reconnect(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCWebSocketClosedError"]({
                message: 'Server requested reconnect'
            }));
        }
    }
    /**
   * Sends a message or batch of messages directly to the server.
   */ send(messageOrMessages) {
        if (!this.activeConnection.isOpen()) {
            throw new Error('Active connection is not open');
        }
        const messages = messageOrMessages instanceof Array ? messageOrMessages : [
            messageOrMessages
        ];
        this.activeConnection.ws.send(JSON.stringify(messages.length === 1 ? messages[0] : messages));
    }
    /**
   * Groups requests for batch sending.
   *
   * @returns A function to abort the batched request.
   */ batchSend(message, callbacks) {
        this.inactivityTimeout.reset();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["run"])(async ()=>{
            if (!this.activeConnection.isOpen()) {
                await this.open();
            }
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sleep"])(0);
            if (!this.requestManager.hasOutgoingRequests()) return;
            this.send(this.requestManager.flush().map(({ message })=>message));
        }).catch((err)=>{
            this.requestManager.delete(message.id);
            callbacks.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(err));
        });
        return this.requestManager.register(message, callbacks);
    }
    constructor(opts){
        /**
   * Observable tracking the current connection state, including errors.
   */ _define_property(this, "connectionState", void 0);
        _define_property(this, "allowReconnect", false);
        _define_property(this, "requestManager", new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$requestManager$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RequestManager"]());
        _define_property(this, "activeConnection", void 0);
        _define_property(this, "reconnectRetryDelay", void 0);
        _define_property(this, "inactivityTimeout", void 0);
        _define_property(this, "callbacks", void 0);
        _define_property(this, "lazyMode", void 0);
        /**
   * Manages the reconnection process for the WebSocket using retry logic.
   * Ensures that only one reconnection attempt is active at a time by tracking the current
   * reconnection state in the `reconnecting` promise.
   */ _define_property(this, "reconnecting", null);
        // Initialize callbacks, connection parameters, and options.
        this.callbacks = {
            onOpen: opts.onOpen,
            onClose: opts.onClose,
            onError: opts.onError
        };
        const lazyOptions = {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$options$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazyDefaults"],
            ...opts.lazy
        };
        // Set up inactivity timeout for lazy connections.
        this.inactivityTimeout = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResettableTimeout"](()=>{
            if (this.requestManager.hasOutgoingRequests() || this.requestManager.hasPendingRequests()) {
                this.inactivityTimeout.reset();
                return;
            }
            this.close().catch(()=>null);
        }, lazyOptions.closeMs);
        // Initialize the WebSocket connection.
        this.activeConnection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$wsConnection$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WsConnection"]({
            WebSocketPonyfill: opts.WebSocket,
            urlOptions: opts,
            keepAlive: {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$options$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keepAliveDefaults"],
                ...opts.keepAlive
            }
        });
        this.activeConnection.wsObservable.subscribe({
            next: (ws)=>{
                if (!ws) return;
                this.setupWebSocketListeners(ws);
            }
        });
        this.reconnectRetryDelay = opts.retryDelayMs ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$options$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["exponentialBackoff"];
        this.lazyMode = lazyOptions.enabled;
        this.connectionState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["behaviorSubject"])({
            type: 'state',
            state: lazyOptions.enabled ? 'idle' : 'connecting',
            error: null
        });
        // Automatically open the connection if lazy mode is disabled.
        if (!this.lazyMode) {
            this.open().catch(()=>null);
        }
    }
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/createWsClient.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createWSClient": (()=>createWSClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$wsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsClient/wsClient.mjs [app-ssr] (ecmascript)");
;
function createWSClient(opts) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsClient$2f$wsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WsClient"](opts);
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsLink.mjs [app-ssr] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "wsLink": (()=>wsLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$createWsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/createWsClient.mjs [app-ssr] (ecmascript)");
;
;
;
function wsLink(opts) {
    const { client } = opts;
    const transformer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTransformer"])(opts.transformer);
    return ()=>{
        return ({ op })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                const connStateSubscription = op.type === 'subscription' ? client.connectionState.subscribe({
                    next (result) {
                        observer.next({
                            result,
                            context: op.context
                        });
                    }
                }) : null;
                const requestSubscription = client.request({
                    op,
                    transformer
                }).subscribe(observer);
                return ()=>{
                    requestSubscription.unsubscribe();
                    connStateSubscription?.unsubscribe();
                };
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsLink.mjs [app-ssr] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$createWsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/createWsClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsLink.mjs [app-ssr] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/inputWithTrackedEventId.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "inputWithTrackedEventId": (()=>inputWithTrackedEventId)
});
function inputWithTrackedEventId(input, lastEventId) {
    if (!lastEventId) {
        return input;
    }
    if (input != null && typeof input !== 'object') {
        return input;
    }
    return {
        ...input ?? {},
        lastEventId
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpSubscriptionLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "httpSubscriptionLink": (()=>httpSubscriptionLink),
    "unstable_httpSubscriptionLink": (()=>unstable_httpSubscriptionLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/behaviorSubject.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$rpc$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/rpc.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$rpc$2f$codes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/rpc/codes.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$stream$2f$sse$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/stream/sse.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/unstable-core-do-not-import/utils.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$inputWithTrackedEventId$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/inputWithTrackedEventId.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/signals.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/transformer.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/httpUtils.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/urlWithConnectionParams.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
async function urlWithConnectionParams(opts) {
    let url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resultOf"])(opts.url);
    if (opts.connectionParams) {
        const params = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resultOf"])(opts.connectionParams);
        const prefix = url.includes('?') ? '&' : '?';
        url += prefix + 'connectionParams=' + encodeURIComponent(JSON.stringify(params));
    }
    return url;
}
/**
 * tRPC error codes that are considered retryable
 * With out of the box SSE, the client will reconnect when these errors are encountered
 */ const codes5xx = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$rpc$2f$codes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPC_ERROR_CODES_BY_KEY"].BAD_GATEWAY,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$rpc$2f$codes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPC_ERROR_CODES_BY_KEY"].SERVICE_UNAVAILABLE,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$rpc$2f$codes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPC_ERROR_CODES_BY_KEY"].GATEWAY_TIMEOUT,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$rpc$2f$codes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPC_ERROR_CODES_BY_KEY"].INTERNAL_SERVER_ERROR
];
/**
 * @see https://trpc.io/docs/client/links/httpSubscriptionLink
 */ function httpSubscriptionLink(opts) {
    const transformer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$transformer$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTransformer"])(opts.transformer);
    return ()=>{
        return ({ op })=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                const { type, path, input } = op;
                /* istanbul ignore if -- @preserve */ if (type !== 'subscription') {
                    throw new Error('httpSubscriptionLink only supports subscriptions');
                }
                let lastEventId = undefined;
                const ac = new AbortController();
                const signal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$signals$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["raceAbortSignals"])(op.signal, ac.signal);
                const eventSourceStream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$stream$2f$sse$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sseStreamConsumer"])({
                    url: async ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$httpUtils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUrl"])({
                            transformer,
                            url: await urlWithConnectionParams(opts),
                            input: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$inputWithTrackedEventId$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inputWithTrackedEventId"])(input, lastEventId),
                            path,
                            type,
                            signal: null
                        }),
                    init: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$urlWithConnectionParams$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resultOf"])(opts.eventSourceOptions, {
                            op
                        }),
                    signal,
                    deserialize: transformer.output.deserialize,
                    EventSource: opts.EventSource ?? globalThis.EventSource
                });
                const connectionState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$behaviorSubject$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["behaviorSubject"])({
                    type: 'state',
                    state: 'connecting',
                    error: null
                });
                const connectionSub = connectionState.subscribe({
                    next (state) {
                        observer.next({
                            result: state
                        });
                    }
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$unstable$2d$core$2d$do$2d$not$2d$import$2f$utils$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["run"])(async ()=>{
                    for await (const chunk of eventSourceStream){
                        switch(chunk.type){
                            case 'ping':
                                break;
                            case 'data':
                                const chunkData = chunk.data;
                                let result;
                                if (chunkData.id) {
                                    // if the `tracked()`-helper is used, we always have an `id` field
                                    lastEventId = chunkData.id;
                                    result = {
                                        id: chunkData.id,
                                        data: chunkData
                                    };
                                } else {
                                    result = {
                                        data: chunkData.data
                                    };
                                }
                                observer.next({
                                    result,
                                    context: {
                                        eventSource: chunk.eventSource
                                    }
                                });
                                break;
                            case 'connected':
                                {
                                    observer.next({
                                        result: {
                                            type: 'started'
                                        },
                                        context: {
                                            eventSource: chunk.eventSource
                                        }
                                    });
                                    connectionState.next({
                                        type: 'state',
                                        state: 'pending',
                                        error: null
                                    });
                                    break;
                                }
                            case 'serialized-error':
                                {
                                    const error = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from({
                                        error: chunk.error
                                    });
                                    if (codes5xx.includes(chunk.error.code)) {
                                        //
                                        connectionState.next({
                                            type: 'state',
                                            state: 'connecting',
                                            error
                                        });
                                        break;
                                    }
                                    //
                                    // non-retryable error, cancel the subscription
                                    throw error;
                                }
                            case 'connecting':
                                {
                                    const lastState = connectionState.get();
                                    const error = chunk.event && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(chunk.event);
                                    if (!error && lastState.state === 'connecting') {
                                        break;
                                    }
                                    connectionState.next({
                                        type: 'state',
                                        state: 'connecting',
                                        error
                                    });
                                    break;
                                }
                            case 'timeout':
                                {
                                    connectionState.next({
                                        type: 'state',
                                        state: 'connecting',
                                        error: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"](`Timeout of ${chunk.ms}ms reached while waiting for a response`)
                                    });
                                }
                        }
                    }
                    observer.next({
                        result: {
                            type: 'stopped'
                        }
                    });
                    connectionState.next({
                        type: 'state',
                        state: 'idle',
                        error: null
                    });
                    observer.complete();
                }).catch((error)=>{
                    observer.error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRPCClientError"].from(error));
                });
                return ()=>{
                    observer.complete();
                    ac.abort();
                    connectionSub.unsubscribe();
                };
            });
        };
    };
}
/**
 * @deprecated use {@link httpSubscriptionLink} instead
 */ const unstable_httpSubscriptionLink = httpSubscriptionLink;
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/retryLink.mjs [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "retryLink": (()=>retryLink)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+server@11.1.2_typescript@5.8.3/node_modules/@trpc/server/dist/observable/observable.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$inputWithTrackedEventId$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/inputWithTrackedEventId.mjs [app-ssr] (ecmascript)");
;
;
/* istanbul ignore file -- @preserve */ // We're not actually exporting this link
/**
 * @see https://trpc.io/docs/v11/client/links/retryLink
 */ function retryLink(opts) {
    // initialized config
    return ()=>{
        // initialized in app
        return (callOpts)=>{
            // initialized for request
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$server$2f$dist$2f$observable$2f$observable$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["observable"])((observer)=>{
                let next$;
                let callNextTimeout = undefined;
                let lastEventId = undefined;
                attempt(1);
                function opWithLastEventId() {
                    const op = callOpts.op;
                    if (!lastEventId) {
                        return op;
                    }
                    return {
                        ...op,
                        input: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$inputWithTrackedEventId$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inputWithTrackedEventId"])(op.input, lastEventId)
                    };
                }
                function attempt(attempts) {
                    const op = opWithLastEventId();
                    next$ = callOpts.next(op).subscribe({
                        error (error) {
                            const shouldRetry = opts.retry({
                                op,
                                attempts,
                                error
                            });
                            if (!shouldRetry) {
                                observer.error(error);
                                return;
                            }
                            const delayMs = opts.retryDelayMs?.(attempts) ?? 0;
                            if (delayMs <= 0) {
                                attempt(attempts + 1);
                                return;
                            }
                            callNextTimeout = setTimeout(()=>attempt(attempts + 1), delayMs);
                        },
                        next (envelope) {
                            //
                            if ((!envelope.result.type || envelope.result.type === 'data') && envelope.result.id) {
                                //
                                lastEventId = envelope.result.id;
                            }
                            observer.next(envelope);
                        },
                        complete () {
                            observer.complete();
                        }
                    });
                }
                return ()=>{
                    next$.unsubscribe();
                    clearTimeout(callNextTimeout);
                };
            });
        };
    };
}
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/index.mjs [app-ssr] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$createTRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCUntypedClient.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$createTRPCClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$getFetch$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/getFetch.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$contentTypes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/contentTypes.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpBatchLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpBatchStreamLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchStreamLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$loggerLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/loggerLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$splitLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/splitLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsLink.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpSubscriptionLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpSubscriptionLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$retryLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/retryLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$createWsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/createWsClient.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/index.mjs [app-ssr] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$createTRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCUntypedClient.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$createTRPCClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/createTRPCClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$getFetch$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/getFetch.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$TRPCClientError$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/TRPCClientError.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$internals$2f$contentTypes$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/internals/contentTypes.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpBatchLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpBatchStreamLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpBatchStreamLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$loggerLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/loggerLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$splitLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/splitLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$wsLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/wsLink.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$httpSubscriptionLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/httpSubscriptionLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$retryLink$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/retryLink.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$internals$2f$TRPCUntypedClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/internals/TRPCUntypedClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$links$2f$wsLink$2f$createWsClient$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/links/wsLink/createWsClient.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$trpc$2b$client$40$11$2e$1$2e$2_$40$trpc$2b$server$40$11$2e$1$2e$2_typescript$40$5$2e$8$2e$3_$5f$typescript$40$5$2e$8$2e$3$2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@trpc+client@11.1.2_@trpc+server@11.1.2_typescript@5.8.3__typescript@5.8.3/node_modules/@trpc/client/dist/index.mjs [app-ssr] (ecmascript) <locals>");
}}),

};

//# sourceMappingURL=ab6bc_%40trpc_client_dist_c92b108f._.js.map