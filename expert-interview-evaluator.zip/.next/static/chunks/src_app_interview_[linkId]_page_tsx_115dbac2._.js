(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f9b876d3._.js",
  "static/chunks/node_modules__pnpm_bfff76ba._.js"
],
    source: "dynamic"
});
