(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_28ec0f8b._.js",
  "static/chunks/src_06e05945._.js"
],
    source: "dynamic"
});
